plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.voicedubai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.voicedubai"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("com.google.mlkit:translate:17.0.3")
}

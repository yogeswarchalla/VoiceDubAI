package com.example.voicedubai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.view.Gravity
import android.graphics.Typeface
import android.util.TypedValue
import androidx.core.app.ActivityCompat
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var heardText: TextView
    private lateinit var translatedText: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private var speechRecognizer: SpeechRecognizer? = null
    private var translator: Translator? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listening = false

    companion object { private const val AUDIO_REQUEST = 1001 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        tts = TextToSpeech(this, this)
        setupTranslator()
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening… speak English" }
                override fun onBeginningOfSpeech() { status.text = "Hearing your voice…" }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Processing speech…" }
                override fun onError(error: Int) {
                    if (listening) {
                        status.text = "Didn't catch that. Restarting…"
                        startListening()
                    } else status.text = "Stopped"
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) translate(text)
                    if (listening) startListening()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        } else {
            status.text = "Speech recognition is not available on this phone."
            startButton.isEnabled = false
        }

        startButton.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_REQUEST)
            } else beginListening()
        }
        stopButton.setOnClickListener { stopListening() }
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        fun label(value: String, size: Float, bold: Boolean = false): TextView =
            TextView(this).apply {
                text = value
                setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
                if (bold) setTypeface(null, Typeface.BOLD)
                setPadding(0, 12, 0, 12)
            }

        layout.addView(label("🎙 VoiceDub AI", 28f, true))
        layout.addView(label("Live English → Telugu voice assistant", 16f))
        status = label("Ready. Tap Start and speak in English.", 15f, true)
        layout.addView(status)
        layout.addView(label("ENGLISH SPEECH", 13f, true))
        heardText = label("Your recognized English words will appear here.", 18f)
        layout.addView(heardText)
        layout.addView(label("TELUGU TRANSLATION", 13f, true))
        translatedText = label("తెలుగు అనువాదం ఇక్కడ కనిపిస్తుంది", 22f)
        layout.addView(translatedText)

        startButton = Button(this).apply { text = "Start listening" }
        stopButton = Button(this).apply { text = "Stop"; isEnabled = true }
        layout.addView(startButton)
        layout.addView(stopButton)
        layout.addView(label("Tip: Use the phone microphone for this first prototype.", 12f))
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun setupTranslator() {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(com.google.mlkit.nl.translate.TranslateLanguage.ENGLISH)
            .setTargetLanguage(com.google.mlkit.nl.translate.TranslateLanguage.TELUGU)
            .build()
        translator = Translation.getClient(options)
        status.text = "Preparing English → Telugu language model…"
        translator?.downloadModelIfNeeded()
            ?.addOnSuccessListener { status.text = "Ready. Tap Start and speak in English." }
            ?.addOnFailureListener { e -> status.text = "Language model download failed: ${e.localizedMessage}" }
    }

    private fun beginListening() {
        listening = true
        startButton.isEnabled = false
        status.text = "Starting microphone…"
        startListening()
    }

    private fun startListening() {
        if (!listening) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { speechRecognizer?.startListening(intent) }
        catch (e: Exception) { status.text = "Could not start speech recognition: ${e.localizedMessage}" }
    }

    private fun translate(english: String) {
        heardText.text = english
        status.text = "Translating…"
        translator?.translate(english)
            ?.addOnSuccessListener { telugu ->
                translatedText.text = telugu
                if (ttsReady) {
                    val result = tts?.setLanguage(Locale("te", "IN"))
                    if (result == TextToSpeech.LANG_MISSING_DATA ||
                        result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        status.text = "Telugu voice is not installed/supported by this device's TTS engine."
                    } else {
                        tts?.speak(telugu, TextToSpeech.QUEUE_FLUSH, null, "voicedub-${System.currentTimeMillis()}")
                        status.text = "Translated. Listening for the next phrase…"
                    }
                } else status.text = "Translated. Telugu voice engine is starting…"
            }
            ?.addOnFailureListener { e -> status.text = "Translation failed: ${e.localizedMessage}" }
    }

    private fun stopListening() {
        listening = false
        speechRecognizer?.stopListening()
        startButton.isEnabled = true
        status.text = "Stopped"
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts?.setLanguage(Locale("te", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                status.text = "Install a Telugu-capable text-to-speech voice on your phone."
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == AUDIO_REQUEST && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            beginListening()
        } else if (requestCode == AUDIO_REQUEST) {
            status.text = "Microphone permission is required."
        }
    }

    override fun onDestroy() {
        listening = false
        speechRecognizer?.destroy()
        translator?.close()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

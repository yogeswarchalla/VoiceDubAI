# VoiceDub AI – Android starter

## What this prototype does
- Listens to English through the phone microphone.
- Uses Android speech recognition to turn each spoken phrase into text.
- Uses Google ML Kit on-device translation (English → Telugu).
- Uses the phone's TextToSpeech engine to speak Telugu.

## Open and run
1. Install Android Studio (current stable).
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `VoiceDubAI_Android` folder.
4. Allow Gradle sync and install any requested Android SDK 35 components.
5. Connect an Android phone with USB debugging enabled, or use an emulator with microphone support.
6. Press Run. Grant microphone permission.
7. Wait for the translation model to download (internet required the first time), then tap **Start listening**.

## Important prototype limitations
- This is phrase-by-phrase, not true continuous simultaneous dubbing. Android speech recognition generally returns a phrase after a pause.
- Speech recognition may use the device's configured recognition service and may require internet.
- Telugu speech output depends on whether the device's installed TextToSpeech engine has a Telugu voice. Install a Telugu voice in Android text-to-speech settings if needed.
- This listens to the phone microphone. It does not capture, extract, or bypass protected audio from Prime Video or other DRM-protected apps.
- For movie dubbing, the next milestone should use a video/audio file that you own or are authorized to process, with timestamped segments and audio/video synchronization.

## Next engineering improvements
- Add a language selector and voice settings.
- Add a queue so translated phrases do not interrupt one another.
- Add transcript history and replay.
- Replace phrase-by-phrase recognition with a streaming speech-to-text service for lower latency.
- Add subtitle timing and a permitted media-file import workflow.
